#!/bin/bash

# Verifier dependencies are installed in environment/Dockerfile.
# Do not apt-get, pip install, curl, or bootstrap uv here when allow_internet = false.

mkdir -p /logs/verifier

if [ "$PWD" = "/" ]; then
    echo "Error: No working directory set. Please set a WORKDIR in your Dockerfile."
    exit 1
fi

python -m pytest -o cache_dir=/tmp/pytest_cache \
  --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA
RC=$?

if [ "$RC" -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi

# TRAINING NOTE: trailing exit after the reward block fails check_test_sh on Edition 2.
# Harbor scores /logs/verifier/reward.txt, not this exit code — delete the line below.
exit "$RC"
