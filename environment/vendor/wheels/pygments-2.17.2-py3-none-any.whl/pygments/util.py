class ClassNotFound(ValueError):
    pass
