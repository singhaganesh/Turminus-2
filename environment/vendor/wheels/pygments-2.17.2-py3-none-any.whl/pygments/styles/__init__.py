def get_style_by_name(name):
    return object
