
from pygments.lexer import Lexer
from pygments.lexers.diff import DiffLexer
from pygments.lexers.python import PythonLexer
from pygments.lexers.special import TextLexer
def get_lexer_by_name(name, **options):
    return Lexer()
