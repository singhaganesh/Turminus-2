from pygments.lexer import Lexer
class TextLexer(Lexer):
    name='text'
