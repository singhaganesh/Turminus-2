from pygments.lexer import Lexer
class DiffLexer(Lexer):
    name='diff'
