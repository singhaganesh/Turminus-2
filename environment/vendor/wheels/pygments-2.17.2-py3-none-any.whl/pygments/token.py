class _TokenType(tuple):
    def __getattr__(self, name):
        return _TokenType(self + (name,))
Token = _TokenType()
Text = Token.Text
Error = Token.Error
