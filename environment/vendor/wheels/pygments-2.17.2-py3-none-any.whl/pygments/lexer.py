class Lexer:
    def get_tokens(self, text):
        yield (None, text)
