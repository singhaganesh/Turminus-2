from pygments.formatter import Formatter
class TerminalFormatter(Formatter):
    name = "terminal"
    def format(self, tokensource, outfile):
        for t, v in tokensource:
            outfile.write(v)
