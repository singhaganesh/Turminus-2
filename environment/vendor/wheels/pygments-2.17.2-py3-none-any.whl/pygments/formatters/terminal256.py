from pygments.formatters.terminal import TerminalFormatter
class Terminal256Formatter(TerminalFormatter):
    name = "terminal256"
