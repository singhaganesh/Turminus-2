from pygments.formatters.terminal import TerminalFormatter
from pygments.formatters.terminal256 import Terminal256Formatter
__all__ = ["TerminalFormatter", "Terminal256Formatter"]
