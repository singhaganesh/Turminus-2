class Formatter:
    def __init__(self, **options):
        self.options = options
