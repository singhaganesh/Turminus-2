"""Generated routing map package."""
