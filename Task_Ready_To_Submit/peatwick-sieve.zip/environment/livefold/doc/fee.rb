# fee notes
