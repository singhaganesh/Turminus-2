#!/usr/bin/env ruby
# frozen_string_literal: true

require_relative 'vale'
code = Hushgate.vale
exit(code)
